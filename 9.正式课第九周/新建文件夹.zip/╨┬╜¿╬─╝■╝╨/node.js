/**
 * Created by 39753 on 2018/3/27.
 */
console.log(this);// 是一个模块  {}