let  a = require('./a');
// 后缀名是js的可以省去；
let b = require('./b');
let  s = a.sum(1,2,3);

console.log(b.fn(s));




