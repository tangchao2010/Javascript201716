var   zf = document.getElementsByTagName("h1")[0];
zf.onclick = function () {
    alert(1);
};